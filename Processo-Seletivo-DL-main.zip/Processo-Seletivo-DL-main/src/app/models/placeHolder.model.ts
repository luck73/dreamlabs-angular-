export class Text {
  public userId: number = 0;
  public id: number = 0;
  public title: string = 'a';
  public body: string = 'a';
}
